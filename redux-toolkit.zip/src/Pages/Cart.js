import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { remove, invtreaseItemQuantity, decreaseItemQuantity, getcartTotal } from '../store/cardSlice'

const Cart = () => {
    let dispatch = useDispatch()
    const { cart, totalQuantity, totalPrice } = useSelector(
        (state) => state.cart
    )
    let Prouct = useSelector((state) => state.cart);
    const removeButton = (produId) => {
        dispatch(remove(produId))
        getcartTotal()
    }
    return (
        <div>
            <h3>Cart</h3>
            <div className='cartWrapper'>
                {
                    Prouct.map((data) =>

                        <div className='cartCard'>
                            <img src={data.img} alt='' />
                            <h5>{data.title} </h5>
                            <h5>{data.price} </h5>
                            <h5>Quantity : {data.quantity}  <button onClick={() => dispatch(decreaseItemQuantity(data.id))}>-</button> <button onClick={() => dispatch(invtreaseItemQuantity(data.id))}> +</button> </ h5>
                            <button className='btn' onClick={() => removeButton(data.id)} >Remove</button>
                        </div>
                    )
                }

            </div>

            <div className='final' style={{ background: "black", padding: "50px", color: "white" }}>
                <span>Result</span>
                <div style={{ display: "felx", flexDirection: "column" }}>
                    <p>Total Items  <span style={{ marginLeft: "5%" }}>{totalQuantity}</span> </p>
                    <p>Total amout <span style={{ marginLeft: "5%" }}>{totalPrice}</span></p>
                </div>
            </div>
        </div>

    )
}
export default Cart
