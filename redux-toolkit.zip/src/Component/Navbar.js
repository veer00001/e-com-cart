import React from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'

// The useSelector hook is used to extract the state of a component from the redux store using the selector function.

const Navbar = () => {
    let items = useSelector((state) => state.cart)
    return (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span className='logo'> Nabar Store </span>
            <div>
                <Link to="/" className='navLink'>Home</Link>
                <span className='cartCount  '>Cart items: </span>
                <Link to='/cart' className='navLink'>Cart {items.length}</Link>
            </div>
        </div>
    )
}
export default Navbar
