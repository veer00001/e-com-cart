import { createSlice } from "@reduxjs/toolkit";

const cartSlice = createSlice({
    name: 'cart',
    initialState: [],
    reducers: {
        add(state, action) {
            let find = state.findIndex((item) => item.id === action.payload.id);
            if (find >= 0) {
                state[find].quantity += 1;
            } else {
                state.push(action.payload)
            }
        },
        remove(state, action) {
            return state.filter(item => item.id !== action.payload)
        },
        getcartTotal(state) {

            (state.forEach(item => console.log(item.price)))

            // let { totalQuantity, totalPrice } = state.cart.price.reduce(
            //     (cartToal, cartItem) => {
            //         const { price, quantity } = cartItem;
            //         const itemTotal = price * quantity;
            //         cartToal.totalPrice += itemTotal;
            //         cartToal.totalQuantity += quantity;
            //         return cartToal;
            //     },
            //     {
            //         totalPrice: 0,
            //         totalQuantity: 0,
            //     },
            // );

            // state.totalPrice = parseInt(totalPrice.toFixed(2));
            // state.totalQuantity = totalQuantity;


        },


        invtreaseItemQuantity: (state, action) => {
            state = state.map((item) => {
                if (item.id == action.payload) {
                    return { ...item, quantity: item.quantity += 1 }
                }
                return item;
            });
        },
        decreaseItemQuantity: (state, action) => {
            state = state.map((item) => {
                if (item.id == action.payload) {
                    return { ...item, quantity: item.quantity -= 1 }
                }
                return item;
            });
        },


    }
});

export const { add, remove, invtreaseItemQuantity, decreaseItemQuantity, getcartTotal } = cartSlice.actions
export default cartSlice.reducer;